
echo  =============================
echo  ==== EBOOK-BASH-CREATOR =====
echo  =============================

if [ "$1" = "" ] ; then 
    echo "Missing $1 as source plain text file."
    exit
  else
    echo "Using $1 as source plain text file."
fi

echo converter plain text document to epub 

rm file.html 
rm file.xhtml 
cat "$1" | while read -r i ; do 
    echo "$i <br> " >> file.html 
done
echo "Current Dir:" 
pwd
html2xhtml  "file.html" > file.xhtml 
cp file.xhtml   EPUB/OEBPS/chapter01.xhtml


make 
ls -ltra *.epub


rm file.html 
rm file.xhtml 

